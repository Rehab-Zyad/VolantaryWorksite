# VolantaryWorksite
#### Video Demo :**<https://youtu.be/XSRD2ASmSnA>**
#### Description
** Hi! **
** Welcome to my CS50 Final Project "web app"titled Volantary Worksite**
** this is a website that allows users to be part of Volantary Worksite their data will save  in a database "jobs.db" **
**  **
**  **
** I tried to make it a responsive and dynamic as possible using Bootstrap **
** I use python, Flask, some html, Javascript, css and database **
** I made four html files , one of them base html to contact other "base.html" **
** I used "main.css" for all pages to make it nice as possible**
** I used javascript "welcome customise for "index.html" when user decide to be one of VolantaryWorksite will see message tell him that "Welcome To Our Volantary Worksite"  **
**  **
**  **
** frist of all at the homepage user will find data of Volantary Work then if user decide to be one of this site he just click on the link" be one of us" **
** then he will go to " be one of us" page and see the message tell him that "Welcome To Our Volantary Worksite" after click ok will add his name,job, age **

** I made all fields required so the user must fill all of the data and for the age I made the minimum age is "13" and the maximum age is "90" **
** so if user add number less than "13" will find message tell him : value must be greater than or equal to "13" **
** in case he enter number more than "90" will find message tell him that: "value must be less than or equal to "90" **
**  **
**  **
** after adding right number then click on submit will go to "all members" page and will find his name,job,age added in the table**
** I used Hover.css effect so if user hover over (mouse over) any row it is highlighted with yellow**
** at all members page user can go back to home page by click on link "back to home page" **
** This is all about my website, thanks for reading**
