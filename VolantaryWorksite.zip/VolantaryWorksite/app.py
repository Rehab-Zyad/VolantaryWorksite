import os

from cs50 import SQL
from flask import Flask, flash, jsonify, redirect, render_template, request, session

# Configure application
app = Flask(__name__)

# Ensure templates are auto-reloaded
app.config["TEMPLATES_AUTO_RELOAD"] = True

# Configure CS50 Library to use SQLite database
db = SQL("sqlite:///jobs.db")

@app.route("/")
def homepage():
    return render_template("homepage.html", methods=["GET", "POST"], pagetitle="homepage")

@app.route("/be_one_of_us", methods=["GET", "POST"])
def index():

    name = request.form.get("name")
    job = request.form.get("job")
    age = request.form.get("age")
    db.execute("INSERT INTO jobs (name, job, age) VALUES(?, ?,?)",name,job,age,)
    jobs = db.execute("SELECT * FROM jobs")
    return render_template("index.html", pagetitle="be_one_of_us", jobs=jobs,custom_js="welcome")

@app.route("/all_members", methods=["GET", "POST"])
def all_members():

    name = request.form.get("name")
    job = request.form.get("job")
    age = request.form.get("age")
    db.execute("INSERT INTO jobs (name, job, age) VALUES(?, ?,?)",name,job,age,)
    jobs = db.execute("SELECT * FROM jobs")
    return render_template("all_members.html", pagetitle="all_members", jobs=jobs)